<h3> Data Mahasiswa </h3>

<form action="" method="post">
<table>
    <tr>
        <td width="120"> Nama Mahasiswa </td>
        <td> <input type="text" name="nama_mahasiswa"> </td>
    </tr>
    <tr>
        <td> alamat </td>
        <td> <input type="text" name="alamat"> </td>
    </tr>
    <tr>
        <td> NIM </td>
        <td> <input type="text" name="NIM"> </td>
    </tr>
    <tr>
        <td></td>
        <td><input type="submit" name="proses" value="Simpan"> </td>
    </tr>
</table>

</form>

<?php
include "koneksi.php";

if(isset($_POST['proses'])){
mysqli_query($koneksi, "insert into data_mahasiswa set  
nama_mahasiswa = '$_POST[nama_mahasiswa]',
alamat = '$_POST[alamat]',
NIM = '$_POST[NIM]'");

echo "data mahasiswa telah tersimpan";

}

?>