<h3> Data Mahasiswa </h3>

<table border="1">
    <tr>
        <th>No</th>
        <th>Nama Mahasiswa </th>
        <th>NIM </th>
        <th>Alamat</th>
        <th colspan="2">Aksi</th>
    </tr>

    <?php
    include "koneksi.php";

    $no=1;
    $ambildata = mysqli_query($koneksi,"select * from data_mahasiswa");
    while($tampil = mysqli_fetch_array($ambildata)){
        echo "
        <tr>
            <td>$no</td>
            <td>$tampil[nama_mahasiswa]</td>
            <td>$tampil[NIM]</td>
            <td>$tampil[alamat]</td>
            <td><a href='?kode=$tampil[NIM]'> Hapus </a></td>
            <td><a href='data-ubah.php?kode=$tampil[NIM]'> Ubah </a></td>
        <tr>";
        $no++;
    }
    ?>
    </table>

    <?php
    include "koneksi.php";

    if(isset($_GET['kode'])){
    mysqli_query($koneksi,"delete  from data_mahasiswa where nim='$_GET[kode]'");
    
    echo "Data berhasil dihapus";
    echo "<meta http-equiv=refresh content=2;URL='data-update.php'>";

    }
    ?>