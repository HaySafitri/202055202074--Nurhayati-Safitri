<?php

$host = "localhost";
$user = "root";
$pass = "";
$database = "uas_db";
$koneksi=mysqli_connect($host, $user, $pass);

if ($koneksi) {
$buka=mysqli_select_db($koneksi,$database);
echo "database dapat terhubung";
if (!$buka){
    echo "database tidak terhubung";
}
}else {
    echo "mysql tidak terhubung";

}
?>