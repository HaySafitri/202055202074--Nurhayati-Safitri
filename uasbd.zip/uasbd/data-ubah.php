<?php
include "koneksi.php";
$sql=mysqli_query($koneksi,"select * from data_mahasiswa where NIM='$_GET[kode]'");
$data=mysqli_fetch_array($sql);

?>

<h3> Ubah Data Mahasiswa </h3>

<form action="" method="post">
<table>
    <tr>
        <td width="120"> NIM </td>
        <td> <input type="text" name="NIM" value="<?php echo $data['NIM']; ?>"> </td>
    </tr>
    <tr>
        <td> Nama Mahasiswa </td>
        <td> <input type="text" name="nama_mahasiswa" value="<?php echo $data['nama_mahasiswa']; ?>"> </td>
    </tr>
    <tr>
        <td> Alamat </td>
        <td> <input type="text" name="alamat" value="<?php echo $data['alamat']; ?>"> </td>
    </tr>
    <tr>
        <td></td>
        <td><input type="submit" name="proses" value="Ubah"> </td>
    </tr>
</table>

</form>

<?php
include "koneksi.php";

if(isset($_POST['proses'])){
mysqli_query($koneksi, "update data_mahasiswa set  
nama_mahasiswa = '$_POST[nama_mahasiswa]',
alamat = '$_POST[alamat]'
where NIM = '$_GET[kode]'");

echo "Data mahasiswa telah diubah";
echo "<meta http-equiv=refresh content=1;URL='data-tampil.php'>";

}

?>